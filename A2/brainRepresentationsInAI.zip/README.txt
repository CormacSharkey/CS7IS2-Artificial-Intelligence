We took a very collaborative approach to this project and are happy to say we all pulled our weight and learned a lot throughout the process. We worked together in the initial ideation and research phase to pick a topic and decide on our scope. We then brought our findings together to define subtopics which we split up to research more deeply and write up. We worked together to review our writeup and bring it together, as well as to decide on the content we would present but we split into teams to finalise the review of the report and the presentation. The topic and final review division was as follows.

Emran Yasser Moustafa
- Neuro-inspired models of reasoning in AI
- Presentation

Dmytro Lutskiv
- Introduction & history of neuro representation in AI
- Presentation

Gunjan Shahapurkar
- Ongoing and future work with a focus on AGI
- Final report review

Cormac Sharkey
- Philosophy, ethics and limitations
- Final report review

Conor Powderly
- Chinese room experiment within philosophy, ethics and limitation & neuromorphic computing
- Final report review

Fiona Eguare
- Ongoing and future work with a focus on mind uploading
- Presentation